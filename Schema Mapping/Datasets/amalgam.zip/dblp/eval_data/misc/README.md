# JSONL Export

Generated on 2025-04-10 04:40:51.848975019 UTC by Fabricate v1.1.0 (eeb90cda1969383f56a2637cbd3037bdf598841c)

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.DArticle: 100 rows => DArticle.jsonl
    public.DBook: 100 rows => DBook.jsonl
    public.DInProceedings: 100 rows => DInProceedings.jsonl
    public.MasterThesis: 100 rows => MasterThesis.jsonl
    public.PhDThesis: 100 rows => PhDThesis.jsonl
    public.PubAuthors: 100 rows => PubAuthors.jsonl
    public.WWW: 100 rows => WWW.jsonl