# JSONL Export

Generated on 2025-04-30 05:02:18.748014819 UTC by Fabricate v1.1.0 (eeb90cda1969383f56a2637cbd3037bdf598841c)

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.Article: 100 rows => Article.jsonl
    public.ArticlePublished: 100 rows => ArticlePublished.jsonl
    public.Author: 100 rows => Author.jsonl
    public.Book: 100 rows => Book.jsonl
    public.BookPublished: 100 rows => BookPublished.jsonl
    public.InCollection: 100 rows => InCollection.jsonl
    public.InCollPublished: 100 rows => InCollPublished.jsonl
    public.InProceedings: 100 rows => InProceedings.jsonl
    public.InprocPublished: 100 rows => InprocPublished.jsonl
    public.Manual: 100 rows => Manual.jsonl
    public.ManualPublished: 100 rows => ManualPublished.jsonl
    public.Misc: 100 rows => Misc.jsonl
    public.MiscPublished: 100 rows => MiscPublished.jsonl
    public.TechPublished: 100 rows => TechPublished.jsonl
    public.TechReport: 100 rows => TechReport.jsonl