# Load in Described.jsonl and Descriptor.jsonl

import json

unique_descriptor_to_dids = dict()
with open("src_jsonl/Descriptor.jsonl", "r") as descriptor_source_f:
    for line in descriptor_source_f:
        if line.strip():
            descriptor_row = json.loads(line)
            descriptor = descriptor_row["Descriptor"]
            if descriptor not in unique_descriptor_to_dids:
                unique_descriptor_to_dids[descriptor] = []
            unique_descriptor_to_dids[descriptor].append(descriptor_row["DID"])

# Deduplicate Descriptor
old_dids_to_deduped_did = dict()
with open("Descriptor.jsonl", "w") as descriptor_dedup_f:
    for descriptor in unique_descriptor_to_dids:
        unique_descriptor_to_dids[descriptor].sort()
        deduped_did = unique_descriptor_to_dids[descriptor].pop(0)

        # write to file as JSON
        descriptor_dedup_f.write(json.dumps({"DID": deduped_did, "Descriptor": descriptor}))
        descriptor_dedup_f.write("\n")

        for old_did in unique_descriptor_to_dids[descriptor]:
            old_dids_to_deduped_did[old_did] = deduped_did

# Update Described DIDs to all point to same deduplicated Descriptor record
with open("src_jsonl/Described.jsonl", "r") as described_source_f, open("Described.jsonl", "w") as described_dedup_f:
    for line in described_source_f:
        if line.strip():
            described_row = json.loads(line)
            this_pid = described_row["PID"]
            this_did = described_row["DID"]
            if this_did in old_dids_to_deduped_did:
                print(f"Deduped {this_did} to {old_dids_to_deduped_did[this_did]}")
                this_did = old_dids_to_deduped_did[this_did]

            # write to file as JSON
            described_dedup_f.write(json.dumps({"PID": this_pid, "DID": this_did}))
            described_dedup_f.write("\n")