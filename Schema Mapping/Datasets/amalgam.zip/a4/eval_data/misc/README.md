# JSONL Export

Generated on 2025-04-30 05:03:41.930966042 UTC by Fabricate v1.1.0 (eeb90cda1969383f56a2637cbd3037bdf598841c)

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.author: 100 rows => author.jsonl
    public.Described: 100 rows => Described.jsonl
    public.descriptor: 100 rows => descriptor.jsonl
    public.loc: 100 rows => loc.jsonl
    public.Located: 100 rows => Located.jsonl
    public.location: 100 rows => location.jsonl
    public.publication: 100 rows => publication.jsonl
    public.record: 100 rows => record.jsonl
    public.Recorded: 100 rows => Recorded.jsonl
    public.Written: 100 rows => Written.jsonl