

From https://www.cs.toronto.edu/~miller/amalgam/ :

The goals of this research project were to develop a schema integration benchmark. A set of databases with similar content but different schemas were designed by a set of students working independently. The benchmark will be used to test and evaluate data integration methods. The schemas and data are publicly available. However, we do ask that you send us email to retrieve the data so we know which research groups are using the benchmark.
Methodology. Four separate students were asked to do the following tasks.

Location of Data & Databases: locate a web source containing bibliographic information.
Design of Schema: design a relational schema for representing the data from their specific source.
Coding of parsers for legacy data parsing: write a parser to translate the data into tuples conforming to their schema.
Bulkload the data into an RDBMS.
To receive a tarred source of all the schemas and databases, please email miller@cs.toronto.edu.

To help determine if this benchmark may be of use in your project, we have included below the four schemas (together with the relational DDL statements needed to create the schemas). We will happily provide the data files and DBMS load statements (currently written for DB2) to any research project.

To reference this benchmark, please use the following citation:

@unpublished{Mil+01,
           author = {Ren\'{e}e J. Miller and Daniel Fisla and Mary Huang
                     and David Kymlicka and Fei Ku and Vivian Lee},
           title = {{The Amalgam Schema and Data Integration Test Suite}},
           note = {www.cs.toronto.edu/~miller/amalgam},
           year = 2001,
           }
		   
		   
Mappings found here: https://github.com/RJMillerLab/ibenchScenarioCollection/tree/master/realworld/amalgam

For a3 to a4, mappings were found here: https://github.com/avielhauer/schematch/tree/main/data/Efes-bib/s3a-s4b/ground_truth

Data:
	a1, a2, a3, a4: from Efes paper
	
	BibTex cleaned up using: https://flamingtempura.github.io/bibtex-tidy/index.html?opt=%7B%22modify%22%3Atrue%2C%22curly%22%3Atrue%2C%22numeric%22%3Atrue%2C%22months%22%3Afalse%2C%22space%22%3A2%2C%22tab%22%3Atrue%2C%22align%22%3A13%2C%22blankLines%22%3Afalse%2C%22duplicates%22%3A%5B%22key%22%2C%22doi%22%2C%22citation%22%2C%22abstract%22%5D%2C%22stripEnclosingBraces%22%3Afalse%2C%22dropAllCaps%22%3Afalse%2C%22escape%22%3Afalse%2C%22sortFields%22%3A%5B%22title%22%2C%22shorttitle%22%2C%22author%22%2C%22year%22%2C%22month%22%2C%22day%22%2C%22journal%22%2C%22booktitle%22%2C%22location%22%2C%22on%22%2C%22publisher%22%2C%22address%22%2C%22series%22%2C%22volume%22%2C%22number%22%2C%22pages%22%2C%22doi%22%2C%22isbn%22%2C%22issn%22%2C%22url%22%2C%22urldate%22%2C%22copyright%22%2C%22category%22%2C%22note%22%2C%22metadata%22%5D%2C%22stripComments%22%3Afalse%2C%22trailingCommas%22%3Afalse%2C%22encodeUrls%22%3Afalse%2C%22tidyComments%22%3Atrue%2C%22removeEmptyFields%22%3Afalse%2C%22removeDuplicateFields%22%3Atrue%2C%22lowercase%22%3Atrue%2C%22backup%22%3Atrue%7D
	
	dblp: https://dblp.uni-trier.de/xml/
     - Total publications ('article', 'inproceedings', 'book', 'phdthesis', 'mastersthesis', 'www'): 11,516,616
		- By type: {'mastersthesis': 27, 'www': 3,749,005, 'article': 3,812,590, 'inproceedings': 3,659,420, 'book': 21,003, 'phdthesis': 142,404}
		- Sampling prob.: {'mastersthesis': 1.0, 'www': 0.00005,
                                                       'article': 0.0001, 'inproceedings': 0.0001,
                                                       'book': 0.008, 'phdthesis': 0.008}
	 - data.json is used as the instance data (s uniform sample of .01% of the original data)
	 
	 
	Evaluation data generated with https://fabricate.mockaroo.com/