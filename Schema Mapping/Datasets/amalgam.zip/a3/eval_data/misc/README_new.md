# JSONL Export

Generated on 2025-04-30 05:03:19.694289194 UTC by Fabricate v1.1.0 (eeb90cda1969383f56a2637cbd3037bdf598841c)

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.article: 100 rows => article.jsonl
    public.articleAuthor: 100 rows => articleAuthor.jsonl
    public.author: 100 rows => author.jsonl
    public.unpubAuthor: 100 rows => unpubAuthor.jsonl
    public.unpublished: 100 rows => unpublished.jsonl