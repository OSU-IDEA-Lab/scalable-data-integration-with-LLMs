# CSV Export

Generated on 2025-04-16 13:06:09.137872238 UTC by Fabricate v1.1.0

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.article: 100 rows => article.csv
    public.articleAuthor: 100 rows => articleAuthor.csv
    public.author: 100 rows => author.csv
    public.unpubAuthor: 100 rows => unpubAuthor.csv
    public.unpublished: 100 rows => unpublished.csv