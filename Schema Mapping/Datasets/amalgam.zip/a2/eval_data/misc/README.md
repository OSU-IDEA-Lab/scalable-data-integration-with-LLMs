# JSONL Export

Generated on 2025-04-30 05:02:45.585979372 UTC by Fabricate v1.1.0 (eeb90cda1969383f56a2637cbd3037bdf598841c)

## Exported tables

This is the list of exported tables, with their corresponding row count and file names:

    public.abstracts: 100 rows => abstracts.jsonl
    public.addresses: 100 rows => addresses.jsonl
    public.allBibs: 100 rows => allBibs.jsonl
    public.authors: 100 rows => authors.jsonl
    public.booktitle: 100 rows => booktitle.jsonl
    public.citBkTitle: 100 rows => citBkTitle.jsonl
    public.citForm: 100 rows => citForm.jsonl
    public.citJournal: 100 rows => citJournal.jsonl
    public.citKeyWord: 100 rows => citKeyWord.jsonl
    public.citPublisher: 100 rows => citPublisher.jsonl
    public.citSeries: 100 rows => citSeries.jsonl
    public.editors: 100 rows => editors.jsonl
    public.institutions: 100 rows => institutions.jsonl
    public.ISBN: 100 rows => ISBN.jsonl
    public.journal: 100 rows => journal.jsonl
    public.keyWord: 100 rows => keyWord.jsonl
    public.months: 100 rows => months.jsonl
    public.notes: 100 rows => notes.jsonl
    public.numbers: 100 rows => numbers.jsonl
    public.pages: 100 rows => pages.jsonl
    public.publisher: 100 rows => publisher.jsonl
    public.schools: 100 rows => schools.jsonl
    public.series: 100 rows => series.jsonl
    public.titles: 100 rows => titles.jsonl
    public.types: 100 rows => types.jsonl
    public.volumes: 100 rows => volumes.jsonl
    public.years: 100 rows => years.jsonl